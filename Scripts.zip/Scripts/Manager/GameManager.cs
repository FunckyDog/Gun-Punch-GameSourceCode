using Cinemachine;
using UnityEngine;

public class GameManager : Singleton<GameManager>
{
    public bool isEnterMode;

    public void IsEnterMode(bool enterMode) => isEnterMode = enterMode;

}
