using Cinemachine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScreenImpulse : Singleton<ScreenImpulse>
{
    private CinemachineImpulseSource cis;

    public CinemachineConfiner cc;
    public CinemachineVirtualCamera cvc;

    protected override void Awake()
    {
        base.Awake();
        cis = GetComponent<CinemachineImpulseSource>();
    }

    public void Impulse(Vector3 direction, float strength)
    {
        cis.GenerateImpulseWithVelocity(direction);
        cis.GenerateImpulseWithForce(strength);
    }

    public void SetConfinder(PolygonCollider2D shape)
    {
        cc.m_BoundingShape2D = shape;
    }
}
